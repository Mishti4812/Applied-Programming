import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  // define list of items
  items = [];
  newTask: any;

  // Write code to push new item
  submitNewItem() {
    if (this.newTask !== '') {
      const IDtoUse = this.items.length;
      alert(IDtoUse);
      this.items.push({id: IDtoUse, task: str, status: 'Incomplete'});
    }
  }

  // Write code to complete item
  completeItem() {
    this.items[id].status = 'Completed!';
  }

  // Write code to delete item
  deleteItem() {
    alert(id);
    const newList = [];
    for (let i = 0; i < this.items.length; i++) {
      if (i !== id) {
        const item = this.items[i];
        item.id = i;
        newList.push(item);
      }
    }
    this.items = newList;
  }

}
