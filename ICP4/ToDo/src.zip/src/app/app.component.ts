import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  title = 'ToDoList';
  name = '';
  toDo = [];

  inputText() {
    (<HTMLInputElement>document.getElementById('addThis')).value = '';
  }

  delete(item) {
    const newList = [];
    for (let i = 0; i < this.toDo.length; i++) {
      if (item.itemName !== this.toDo[i].itemName) {
        newList.push(this.toDo[i]);
      }
    }
    this.toDo = newList;
    this.inputText();
  }

  new(task) {
    const newItem = (<HTMLInputElement>document.getElementById('addThis')).value;
    const item = {
      itemName: newItem,
      done: false
    };
    this.toDo.push(item);
    this.inputText();
  }
}

