import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'CalculatorICP';
  displayId = 'display';
  arr = [];

  newDisplay() {
    document.getElementById(this.displayId).innerText = this.arr.join(" ");
  }

  calcNumber(number) {
    number = number.target.textContent;
    if (isNaN(this.arr[this.arr.length - 1])) {
      this.arr.push(number.toString());
    } else {
      this.arr[this.arr.length - 1] += number.toString();
    }
    this.newDisplay();
  }

  calcOperation(operator) {
    operator = operator.target.textContent;
    if (!isNaN(this.arr[this.arr.length - 1])) {
      if (operator === ".") {
        if (!this.arr[this.arr.length - 1].includes(".")) {
          this.arr[this.arr.length - 1] += operator.toString();
        }
      } else {
        this.arr.push(operator);
      }
      this.newDisplay();
    }
  }
  clear(funcName) {
    this.arr = [];
    this.newDisplay();
  }

  erase() {
    this.arr.pop();
    this.newDisplay();
  }

  calculation() {
    var total = eval(this.arr.join(" "));
    this.arr = [total];
    this.newDisplay();
  }
}
