import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'CalculatorICP';
  answer: any = '';
  first: any = 'empty';
  second = 0;
  operation: string;
  number(j: any) {
    if (j === 111) {
      if (this.operation === 'add') {
        this.answer = this.first + this.second;
        this.first = 'empty';
        this.second = 0;
      } else if (this.operation === 'sub') {
        this.answer = this.first - this.second;
        this.first = 'empty';
        this.second = 0;
      } else if (this.operation === 'multi') {
        this.answer = this.first * this.second;
        this.first = 'empty';
        this.second = 0;
      } else if (this.operation === 'divide') {
        this.answer = this.first / this.second;
        this.first = 'empty';
        this.second = 0;
      } else {
        this.answer = '';
      }
    } else {
      if (this.first === 'empty') {
        this.first = j;
      } else {
        this.second = j;
      }
    }
  }
}

